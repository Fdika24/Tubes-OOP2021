package com.company.model.monsters;

public enum MonsterState {
    ALIVE,
    DEAD
}
