package com.company.model.moveModel;

public enum MoveTarget {
    ENEMY,
    OWN
}
