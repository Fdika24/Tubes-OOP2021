package com.company.model.moveModel;

public enum MoveType {
    NORMAL,
    SPECIAL,
    STATS,
}
