package com.company.model.moveModel;

public enum EffectType {
    NONE, // GA ADA
    POISON,
    SLEEP,
    PARALYZE,
    BURN
}
