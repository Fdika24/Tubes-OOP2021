package com.company.model;

public enum ElementType {
    NORMAL,
    FIRE,
    WATER,
    GRASS
}
