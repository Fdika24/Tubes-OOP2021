package com.company.rootFolder;

public class Main {
    private static RootController root = new RootController();
    public static void main(String[] args) {
        root.start();
    }
}
