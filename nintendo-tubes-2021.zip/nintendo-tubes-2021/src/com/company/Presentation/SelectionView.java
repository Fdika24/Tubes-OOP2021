package com.company.Presentation;

import com.company.extention.UIViewController;

public class SelectionView extends UIViewController {
    @Override
    protected void viewDidLoad() {
        super.viewDidLoad();
    }
}
