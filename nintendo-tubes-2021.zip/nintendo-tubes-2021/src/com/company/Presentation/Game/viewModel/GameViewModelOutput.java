package com.company.Presentation.Game.viewModel;

public interface GameViewModelOutput {
    public void didTapShowMenu();
    public void didAllMonstersDead();
    public void didSuccessDoAction();
    public void didFailDoAction();
}
