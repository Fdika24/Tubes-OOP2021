package com.company.extention;

import java.util.Stack;

public class UIViewController  {

    public UINavigationController navigationController;

    /*
        what        :
        how to use  :
    */
    protected void viewDidLoad() {

    }
    /*
        what        :
        how to use  :
    */
    protected void loadView() {

    }
    /*
        what        :
        how to use  :
    */
    protected void viewDidFinnish() {

    }
    /*
        what        :
        how to use  :
    */
    protected  void deleteView() {

    }
}
