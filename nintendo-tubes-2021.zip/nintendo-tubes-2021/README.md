# Tubes Framework
Your Tubes OOP solution
## What is this?

Tubes framework is a framework to ease up your Tugas Besar Development.
Tubes framework built on top Java and inspired by Apple AppKit and UIKit.

## How to Run it

Clone this repo and you're ready. There's no need to set any enviroment other than Java 8+.

## How to Use it

All you have to do is remember 2 concept, ViewController - Model or in short MVC Architecture.
Sounds hard right? It's actually quite easy. ViewControllers is where you code your logics and everything while model is simply your data type.

## ViewController LifeCycle

** Run this project first to understand viewcontroller lifecycle, or read UIViewController docs. **

ViewController is the place where you want to do most of your codes. When you push // to be continued